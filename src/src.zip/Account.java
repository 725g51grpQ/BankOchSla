public class Account {
	private String fullnameInt;
	private String usernameInt;
	private String passwordInt;
	private String persNrInt;
	private String addressInt;
	private String phoneInt;
	private String mailInt;
	private String amountInt;
	
	private int warningInt;
	private boolean blockedInt;
	
	public Account(String fullname, String username, String password, String persNr, 
					String address, String phone, String mail, String amount){
		fullnameInt = fullname;
		usernameInt = username;
		passwordInt = password;
		persNrInt = persNr;
		addressInt = address;
		phoneInt = phone;
		mailInt = mail;
		amountInt = amount;
		
		blockedInt = false;
		warningInt = 0;
	}

	public String getFullname(){
		return fullnameInt;
	}
	public String getUsername(){
		return usernameInt;
	}
	public String getPassword(){
		return passwordInt;
	}
	public String getPersNr(){
		return persNrInt;
	}
	public String getAddress(){
		return addressInt;
	}
	public String getPhone(){
		return phoneInt;
	}
	public String getMail(){
		return mailInt;
	}
	public String getAmount(){
		return amountInt;
	}
	public boolean isBlocked(){
		return blockedInt;
	}
	public int getWarnings(){
		return warningInt;
	}
	public void addMoney(String amount){
		try{
			amountInt = "" + (Double.parseDouble(amountInt) + Double.parseDouble(amount)); 
		}
		catch(Exception e){
			System.out.println("N�got gick fel. Error: " + e);
		}
	}
	
	public void setFullname(String fullname){
		fullnameInt = fullname;
	}
	public void setUsername(String username){
		usernameInt = username;
	}
	public void setPassword(String password){
		passwordInt = password;
	}
	public void setPersNr(String persNr){
		persNrInt = persNr;
	}
	public void setAddress(String address){
		addressInt = address;
	}
	public void setPhone(String phone){
		phoneInt = phone;
	}
	public void setMail(String mail){
		mailInt = mail;
	}
	public void setAmount(String amount){
		amountInt = amount;
	}
		
	public boolean sendEmail(String msg){
		//Skicka mail h�r
		return true;
	}
	public void setBlocked(){
		blockedInt = true;
	}
	public void setUnblocked(){
		blockedInt = false;
	}

	public void giveWarning(){
		warningInt++;
		if(warningInt >= 3){
			this.setBlocked();
		}
	}

	public void removeWarning(){
		if(warningInt > 0){
			warningInt--;
		}
		if(this.isBlocked()){
			this.setUnblocked();
		}
	}
	public boolean pay(String amount, String time) {
		try {
			double temp = Double.parseDouble(amountInt);
			temp -= Double.parseDouble(amount);
			amountInt = Double.toString(temp);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean receive(String amount, String time) {
		try {
			double temp = Double.parseDouble(amountInt);
			temp += Double.parseDouble(amount);
			amountInt = Double.toString(temp);
			return true;
		} catch (Exception e) {
			return false;
		}

	}
}