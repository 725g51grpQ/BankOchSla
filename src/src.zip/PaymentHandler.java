import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class PaymentHandler {
	private String timeInt;

	public void PaymentHandler(){}
	
	public ArrayList<Account> pay(Account seller, String amount, Account buyer) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	    Date now = new Date();
	    timeInt = sdf.format(now);
	    
	    buyer.pay(amount, timeInt);
		seller.receive(amount, timeInt);

		ArrayList<Account> accounts = new ArrayList<Account>();
		
		accounts.add(buyer);
		accounts.add(seller);
		
		return accounts;
	}
	
}