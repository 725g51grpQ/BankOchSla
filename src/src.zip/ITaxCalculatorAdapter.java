interface ITaxCalculatorAdapter{
	//Anropet ger som retur en str�ng med ett meddelande fr�n den externa tj�nsten
	public String getTaxes(String s);
}