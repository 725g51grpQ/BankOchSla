public class Bid {
	private Account buyerInt;
	private String amountInt;

	public Bid(String amount, Account Buyer) {
		amountInt = amount;
		buyerInt = Buyer;
	}
	
	public String getAmount(){
		return amountInt;
	}

	public Account getBuyer(){
		return buyerInt;
	}
}