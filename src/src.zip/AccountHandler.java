import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class AccountHandler {
	private ArrayList<Account> accountsCatalog = new ArrayList<Account>();
	public void AccountHandler(){}
	
	public void createUser(String fullname, String username, String password, String persNr, String address, String phone, String mail, String amount){
		Account acc = new Account(fullname, username, password, persNr, address, phone, mail, amount);
		acc.sendEmail("Confirmation msg");
		accountsCatalog.add(acc);
	}	
	
	public ArrayList<Account> pay(Account buyer, Account seller, String amount){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	    Date now = new Date();
	    String time = sdf.format(now);
	    
	    buyer.pay(amount, time);
		seller.receive(amount, time);

		ArrayList<Account> accounts = new ArrayList<Account>();
		
		accounts.add(seller);
		accounts.add(buyer);
		
		return accounts;
	}

	public Account getAccount(String username){
		ArrayList<Account> accounts = getAccounts();
		for(int i = 0; i<accounts.size(); i++){
			if(accounts.get(i).getUsername().equals(username)){
				return accounts.get(i);
			}
		}
		return null;
	}
	
	public ArrayList<Account> getAccounts(){
		return accountsCatalog;
	}
	
	public Account getLatestAccount(){
		return accountsCatalog.get(accountsCatalog.size()-1);
	}

	public void sendEmail(Account account, String msg){
		account.sendEmail(msg);
	}
	
	public void emailAllUsers(String msg){
		for(int i = 0; i<accountsCatalog.size(); i++){
			accountsCatalog.get(i).sendEmail(msg);
		}
	}

	public void setBlocked(Account account){
		account.setBlocked();
	}
	
	public void setUnblocked(Account account){
		account.setUnblocked();
	}
	
	public void giveWarning(Account account){
		account.giveWarning();
	}
	
	public void removeWarning(Account account){
		account.removeWarning();
	}
	
	public boolean isBlocked(Account account){
		return account.isBlocked();
	}
	
	public int getWarnings(Account account){
		return account.getWarnings();
	}

}			