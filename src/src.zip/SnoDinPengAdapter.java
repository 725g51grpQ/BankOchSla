

class SnoDinPengAdapter implements ITaxCalculatorAdapter{
	public String getTaxes(String s)
	{
		String taxValue = "17";
		return taxValue;
	};
}
