import java.util.ArrayList;
public class AuctionHandler {
	private ArrayList<Auction> auctionsCatalog = new ArrayList<Auction>();
	private ITaxCalculatorAdapter taxAdapter;

	public void initialize() {
		taxAdapter = TaxFactory.getInstance().getTaxAdapter();
	}
	
	public AuctionHandler(){
		
	}
	
	public void newAuction(String title, String duration,
			String auctionType, String desc, String img, String lowPrice,
			String startPrice, String buyout, String delivery, Account seller,
			String category, String time) {
			Auction auction = new Auction(title, duration, auctionType, desc, img, lowPrice,
					startPrice, buyout, delivery, seller, category, time);
			auctionsCatalog.add(auction);
	}
	public ArrayList<Auction> getAuctionsList(){
		return auctionsCatalog;
	}
	
	public String getTax(){
		return taxAdapter.getTaxes("20");
	}


	public Auction getLatestAuction(){
		return auctionsCatalog.get(auctionsCatalog.size()-1);
	}
	
	public void endAuction(Auction auction) {
		Account seller = auction.getSeller();
		String amount = auction.getLatestBid().getAmount();
		Account buyer = auction.getLatestBid().getBuyer();
		PaymentHandler ph = new PaymentHandler();
		ph.pay(seller, amount, buyer);
		auction.endAuction();
	}
	
	public void newBid(String amount, Account buyer, Auction auction){
		auction.newBid(amount, buyer);
	}
	

	public void itemSent(Auction auction, String time, String trackingId){
		auction.itemSent(time, trackingId);
	}
	
	public boolean isItemSent(Auction auction){
		return auction.isItemSent();
	}

	public void itemReceived(Auction auction, String time){
		auction.itemReceived(time);
	}
	
	public boolean isItemReceived(Auction auction){
		return auction.isItemReceived();
	}
	
	public void remindBuyerMarkReceived(Auction auction){
		auction.remindBuyerMarkReceived();
	}
	
	public void printAuctions(){
		for( int i = 0; i < this.getAuctionsList().size(); i++){
			System.out.println(this.getAuctionsList().get(i).toString() + "\n\n");
		}
	}
	
}